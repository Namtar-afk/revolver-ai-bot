Formule **3 hypothèses stratégiques** basées sur le brief et les tendances.
Chaque hypothèse doit être présentée sous forme d’énoncé clair, validable via données ultérieures.
Exemple :

- Hypothèse 1
- Hypothèse 2
