Génère **3 à 5 insights actionnables** à partir du brief et des tendances.
Chaque insight doit être court (1 ligne) et centré sur un bénéfice ou une opportunité concrète.
Bullet points autorisés :

- Insight 1
- Insight 2
- Insight 3
