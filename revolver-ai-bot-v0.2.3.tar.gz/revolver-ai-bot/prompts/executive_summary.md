Rédige un résumé exécutif en **2–3 phrases**.
Doit synthétiser le contexte, les insights clés et les recommandations principales pour un lecteur non spécialiste.
