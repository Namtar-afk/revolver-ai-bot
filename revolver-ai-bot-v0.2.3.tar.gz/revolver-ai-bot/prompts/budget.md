Estime le **budget** pour chaque grande catégorie (Production, Média, Influence…).
Format :

- Production vidéo — 5 000€ — Commentaires
- Achat d’espace média — 10 000€ — Commentaires
