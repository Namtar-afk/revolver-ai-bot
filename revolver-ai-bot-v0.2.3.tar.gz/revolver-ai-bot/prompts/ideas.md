Liste **3 idées créatives** pour illustrer la campagne.
Présente chaque idée en une ligne, avec un titre et un bref descriptif.
