Construit une **chronologie** simple (timeline) avec **3–4 étapes** majeures.
Format recommandé :

- Étape 1 : Description — Date cible
- Étape 2 : …
