# … en haut du fichier existant …

def summarize_items(items: list[dict]) -> str:
    """
    Agrège les thèmes détectés pour en faire un petit paragraphe.
    """
    return "Résumé factice des thèmes majeurs."

def detect_trends(items: list[dict]) -> list[str]:
    """
    Extrait une liste de thèmes à partir des items de veille.
    """
    return ["Tendance A", "Tendance B", "Tendance C"]
